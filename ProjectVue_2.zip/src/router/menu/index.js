import Home from "./_home";
import Products from "./_products";
import Support from "./_support";

// defines here your routes definitions
export {
  Home,
  Products,
  Support
};
