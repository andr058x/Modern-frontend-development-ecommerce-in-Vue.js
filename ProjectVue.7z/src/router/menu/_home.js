export default {
    path: "/home",
    name: "home",
    component: function(resolve) {
      require(["@/components/Layout/AppLayout.vue"], resolve);
    },
    redirect: "/home/index",
    children: [
    //   {
    //     path: ":tab(account|history|notify)",
    //     name: "bill4me_section",
    //     component: function(resolve) {
    //       require(["@/components/Bill4Me/Index.vue"], resolve);
    //     }
    //   },
    {
        path: "index",
        name: "index",
        component: function(resolve) {
          require(["@/components/Home/Index.vue"], resolve);
        },
        // props: route => {
        //   return {
        //     token: route.params.token
        //   };
        // }
      },
    ]
  };
  