import Home from "./_home";


// defines here your routes definitions
export {
  Home
};
