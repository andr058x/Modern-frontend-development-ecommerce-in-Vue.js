<template>
  <header>
    <div class="flex-container header_top">
        <div class="flex-cell header_logo cell-1of3 medium-cell-1of3 small-cell-1of1 xs-cell-1of1 priority-0">
          <div class="logo"></div>
        </div>
        <div class="flex-cell cell-1of2 medium-cell-1of3 small-cell-1of1 xs-cell-1of1 priority-1">
          <div class=""></div>
        </div>
        <div class="flex-cell cell-1of6 medium-cell-1of3 small-cell-1of1 xs-cell-1of1 priority-2">
          <div class="flex-container header_cartbox">
            <div class="flex-cell cell-1of6 medium-cell-1of3">
              <i class="fa fa-shopping-cart"></i>
            </div>           
            <span class="flex-cell cell-auto">
              KR 1030 CHECKOUT
            </span>          
          </div>
        </div>
    </div>
    <div class="flex-container header_bottom">
      <div class="flex-cell cell-1of2 medium-cell-1of1 header_navbar">
        <nav>
          <ul class="header_container">
            <li class="header_navitem"><a href="">HOME</a></li>
            <li class="header_navitem"><a href="">MEN</a></li>
            <li class="header_navitem"><a href="">WOMEN</a></li>
            <li class="header_navitem"><a href="">KIDS</a></li>
            <li class="header_navitem"><a href="">SALE</a></li>
            <li class="header_navitem"><a href="">ABOUT US</a></li>
            <li class="header_navitem"><a href="">SUPPORT</a></li>
          </ul>        
        </nav>
      </div>
      <div class="flex-cell cell-1of3 medium-cell-none small-cell-none"></div>
      <div class="flex-cell cell-1of6 medium-cell-1of2 small-cell-1of1">
          <div class="flex-container header_search">
            <div class="flex-cell cell-1of6 medium-cell-1of6">
              <i class="fa fa-search"></i>
            </div>           
            <div class="flex-cell cell-auto medium-cell-1of6">
              <input type="text" placeholder="Search"/>
            </div>          
          </div>        
      </div>
    </div>
    <div class="flex-container header_sub"></div>
  </header>
</template>

<script>

export default {
  name: "AppHeader",
  components: {
  },
//   computed: mapGetters({
//   })
};
</script>

<style lang="scss">

.header_logo{
  text-align: right;
  vertical-align: middle;
  margin-top: 10px;
}

.header_cartbox{
  background-color: #ededed;
  color: #7e7f84;
  padding:15px;
}

.header_cartbox span{
  margin-top: 3px;
}

.header_navbar ul {
  padding: 0;
  list-style: none;
}

.header_navitem a {
  text-decoration: none;
  color: #7e7f84;
}

.header_navitem a:hover {
  color: #f45a40;
}

.header_top{
  min-height: 55px;
  border-bottom: 1px solid #7e7f84;
}

.header_bottom{
  border-bottom: 10px solid #f45a40;
}

.header_sub{
  height: 5px;
  border-bottom: 2px solid #f45a40;
}

.header_search {
  margin-top: 15px;
}

.header_search input {
  border-radius: 2px;
}

.header_navbar li + li {
    margin-left:0px;
}

.header_container > li {  
  flex: 1;  
}

.header_container {  
  display: flex;  
} 

.header_search {  
  flex: 1;  
}    

@media all and (min-width: 801px) {
    .header_navbar li:first-child{
    margin-left:15px;
  }
}

@media all and (max-width: 800px) {   
  .header_container {  
    flex-wrap: wrap;  
  }  
    
  .header_container > li {  
    flex-basis: 50%;  
  }

  .header_logo{
    text-align: center;
    vertical-align: middle;
    margin-top: 10px;
  }
}

@media all and (max-width: 400px) {  
  .header_container > li {  
    flex-basis: 100%;  
  }  
  .header_search {  
    order: 1;  
  }  
}

</style>
