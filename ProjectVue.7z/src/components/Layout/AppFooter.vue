<template>
  <footer class="">
    <div class="flex-container container-align-center footer_top">
        <div class="flex-cell cell-1of3 small-cell-1of1 priority-0 cell-x-align-center">
          tegttrhrth
        </div>        
        <div class="flex-cell cell-1of3 small-cell-1of1 priority-1 cell-x-align-center">
          <input type="text">
          <button>SIGN UP</button>
        </div>
    </div>    
    <div class="flex-container footer_bottom">
        <div class="flex-cell cell-logo cell-1of3 medium-cell-1of3 small-cell-1of1 xs-cell-1of1 priority-1">
        </div>
    </div>
  </footer>
</template>

<script>
export default {
  name: "AppFooter",
  computed: {
    version() {
      return `1.1.0`;
    }
  }
};
</script>

<style lang="scss">

.footer_top {
  min-height: 80px;
  color: white;
  background-color: #f45a40;
  button{
    background-color: #ff674f;
		padding: 8px 16px;
    font-size: 16px;
    color: white;
  }
}

.footer_bottom{
  min-height: 300px;
  background-color: #2a2d34
}



@media all and (min-width: 801px) {

}

@media all and (max-width: 600px) {  
    


}

@media all and (max-width: 400px) {  

}

</style>

