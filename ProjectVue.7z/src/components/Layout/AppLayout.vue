<template>
<div class="flex-container aligner">
  <div class="">
    <app-header />
    <app-content />
    <app-footer />
  </div>
</div>
</template>

<script>
import AppHeader from "./AppHeader.vue";
import AppContent from "./AppContent.vue";
import AppFooter from "./AppFooter.vue";

export default {
  components: {
    AppHeader,
    AppContent,
    AppFooter
  }
};
</script>