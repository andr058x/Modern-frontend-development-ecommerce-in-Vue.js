<template>
  <div class="">
    <div class="">
      <router-view />
    </div>
  </div>
</template>

<script>
export default {};
</script>