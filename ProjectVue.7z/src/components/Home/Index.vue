<template>
<div>
	<div class="flex-container container-align-center home_upperprod">
		<div class="flex-cell cell-1of4 home_upperprod_box"  v-for="item in upperProducts" v-bind:key="item.id">
			<div class="flex-container">
				<div class="flex-cell cell-1of1">
					<img :src="getImgUrl(item.url)" alt="">
				</div>
			</div>
			<div class="flex-container home_textleft">
				<div class="flex-cell cell-1of1">
					<a href="#">{{item.linkTitle}}</a>
				</div>
			</div>			
			<div class="flex-container home_textleft">
				<div class="flex-cell cell-1of1">
					<span>{{item.desc}}</span>
				</div>
			</div>
		</div>
	</div>

	<div class="flex-container container-align-center home_textproducts">
		<div class="flex-cell cell-1of1">
			<p>POPULAR PRODUCTS</p>
		</div>
	</div>

	<div class="flex-container container-align-center home_prod">
		<div class="flex-cell cell-1of5 medium-cell-1of2 small-cell-1of1 home_prod_box" v-for="item in products" v-bind:key="item.id">
			<div class="flex-container">
				<div class="flex-cell cell-1of1">
					<i class="fa fa-xs" :class="{'color-warn fa-star' : s == true, 'fa-star' : s == false}" v-for="s in item.stars" v-bind:key="s.$index"></i>
				</div>
			</div>			
			<div class="flex-container container-align-left home_prodimg_box">
				<div class="flex-cell cell-1of5 cell-x-align-end">
					<img :src="getImgUrl(item.imgUrl)" alt="">
				</div>
			</div>
			<div class="flex-container home_prod_name">
				<div class="flex-cell cell-1of1">
					<span>{{item.name}}</span>
				</div>
			</div>	
			<div class="flex-container home_prod_category">
				<div class="flex-cell cell-1of1">
					<span>{{getCategory(item.categoryId).desc}}</span>
				</div>
			</div>				
			<div class="flex-container home_prod_desc">
				<div class="flex-cell cell-1of1">
					<span>{{item.desc}}</span>
				</div>
			</div>				
			<div class="flex-container home_prod_price">
				<div class="flex-cell cell-auto">
					<span>KR {{item.price}}</span>
				</div>				
				<div class="flex-cell cell-1of5">
					<i class="fa fa-sm fa-heart"></i>
					<i class="fa fa-sm fa-plus-circle"></i>
				</div>
			</div>	
			<div class="flex-container home_prod_buy">
				<div class="flex-cell cell-1of1">
					<button>BUY NOW</button>
				</div>
			</div>	
		</div>
	</div>
</div>

    <!-- <div class="flex-container header_top homeImage">
        <div class="flex-cell cell-1of1">
        </div>
    </div> -->
</template>

<script>
import jsorReader from "../Axios/jsonReader"
export default {
  components: {
  },

  mounted(){
	  jsorReader.getUpperProducts().then(response => {
		  this.upperProducts = response.data.items;
        })
        .catch(errorResponse => {
			console.log(errorResponse);
		})	  

	  jsorReader.getProducts().then(response => {
		  this.products = response.data.items;
		  this.categories = response.data.categories;
        })
        .catch(errorResponse => {
			console.log(errorResponse);
		})	  
  },

  data(){
	  return {
		upperProducts: [],
		products: [],
		categories: [],
	  }
  },

  methods:{
	getImgUrl(pet) {
		var images = require.context('../../assets/img/products/', false, /\.png$/)
		return images('./' + pet)
	},
	getCategory(id){
		return  _.head(_.filter(this.categories, function(o) { return o.id == id; }));
	}
  }
  
//   computed: mapGetters({
//   })
};
</script>

<style lang="scss">
.home_textproducts{
	text-align: center;
}
.home_image{    
  background-image: url("../../assets/img/homeImage.png");
  width: 1280px;
  height: 1028px;
}
.home_upperprod{
	img {
		max-width: 300px;
	}
	a {
		text-align: left;
		text-decoration: none;
		color:  #f45a40;
	}
	a:hover{
		text-decoration: underline;
	}
	span{
		color: #7e7f84;
		font-size: 10pt
	}
}
.home_upperprod_box{
	margin:10px;
}
.home_prod{
	a {
		text-align: left;
		text-decoration: none;
		color:  #f45a40;
	}
	a:hover{
		text-decoration: underline;
	}
	span{
		color: #7e7f84;
		font-size: 10pt
	}
}
.home_textproducts{
	color: #7e7f84;
	font-size: 12pt;
}
.home_prod_box{
	color: #7e7f84;
	margin:12px;
}
.home_prodimg_box{
	min-height: 178px;
}
.home_prod_name{
	margin-top: 15px;
	text-transform: uppercase; 
	span{
		font-size: 12pt;
	}
}
.home_prod_category{
	text-transform: uppercase; 
	span{
		font-size: 10pt;
	}
}
.home_prod_price{
	margin-top: 10px;
	i {
		margin-left: 2px;
		margin-right: 2px;
	}
	span{
		color:  #f45a40;
		font-size: 10pt;
		font-weight: bold;
	}
}
.home_prod_buy{
	margin-top: 5px;
	button{
		width: 100%;
		background-color:  #f45a40;
		color: white;
		padding: 8px 16px;
		font-size: 16px;
	}
}
</style>
